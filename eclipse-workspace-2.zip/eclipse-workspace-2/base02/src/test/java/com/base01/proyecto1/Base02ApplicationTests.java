package com.base01.proyecto1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Base02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
