package com.example.demo.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.demo.Demo2Application;
import org.slf4j.ILoggerFactory;



public class PersonaRepositoryImplements implements IPersona{
	private Logger LOG =LoggerFactory.getLogger(Demo2Application.class);

	@Override
	public void registra(String nombre) {
		// TODO Auto-generated method stub
		
	}


}
