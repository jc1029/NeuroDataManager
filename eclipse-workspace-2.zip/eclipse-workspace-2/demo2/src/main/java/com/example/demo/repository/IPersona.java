package com.example.demo.repository;

public interface IPersona {
	void registra (String nombre);

}
