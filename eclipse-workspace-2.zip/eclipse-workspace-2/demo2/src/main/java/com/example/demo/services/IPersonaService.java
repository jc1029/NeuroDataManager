package com.example.demo.services;

public class IPersonaService {
	void registra(String nombre);

}
